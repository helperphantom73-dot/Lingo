package com.lingoworld.app.data.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "word_progress")
data class WordProgressEntity(
    @PrimaryKey val wordId: String,
    val box: Int = 1, // 1..5 Leitner box
    val mastery: Int = 0, // 0..100
    val lastSeen: Long = System.currentTimeMillis(),
    val correctCount: Int = 0,
    val wrongCount: Int = 0
)

@Entity(tableName = "seen_sentences")
data class SeenSentenceEntity(
    @PrimaryKey val fingerprint: String, // Hash of templateId + slotted word IDs
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_stats")
data class DailyStatEntity(
    @PrimaryKey val date: String, // YYYY-MM-DD
    val xp: Int = 0,
    val minutes: Int = 0,
    val correct: Int = 0,
    val wrong: Int = 0
)

@Entity(tableName = "badges")
data class BadgeEntity(
    @PrimaryKey val id: String,
    val titleFa: String,
    val titleEn: String,
    val descFa: String,
    val icon: String,
    val unlockedAt: Long? = null,
    val category: String
)
