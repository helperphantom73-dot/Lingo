package com.lingoworld.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.lingoworld.app.data.datastore.UserPreferences
import com.lingoworld.app.ui.components.NeonBackground
import com.lingoworld.app.ui.screens.onboarding.OnboardingScreen
import com.lingoworld.app.ui.theme.LingoWorldTheme
import com.lingoworld.app.ui.theme.NeonBlueBg
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LingoWorldTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = NeonBlueBg
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val context = LocalContext.current
    val prefs = UserPreferences(context)

    // FIX: Read onboarding status from DataStore so it persists across restarts
    val isOnboardingDone by prefs.isOnboardingDone.collectAsState(initial = false)

    Box(modifier = Modifier.fillMaxSize()) {
        // FIX: Pass graphicTier from prefs to NeonBackground
        val graphicTier by prefs.graphicTier.collectAsState(initial = "high")
        NeonBackground(isLowPowerMode = graphicTier == "low")

        if (!isOnboardingDone) {
            OnboardingScreen(
                onComplete = { name, age, level, interests ->
                    // FIX: Actually save onboarding data to DataStore
                    CoroutineScope(Dispatchers.IO).launch {
                        prefs.saveProfile(name, age, level, interests.toSet())
                    }
                }
            )
        }
        // TODO: Add main HomeScreen here when isOnboardingDone == true
    }
}
