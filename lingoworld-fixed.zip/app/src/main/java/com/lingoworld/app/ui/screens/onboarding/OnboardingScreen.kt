package com.lingoworld.app.ui.screens.onboarding

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lingoworld.app.ui.components.BubbleButton
import com.lingoworld.app.ui.components.GlassCard
import com.lingoworld.app.ui.components.LumoState
import com.lingoworld.app.ui.components.LumoView
import com.lingoworld.app.ui.theme.NeonBluePrimary
import com.lingoworld.app.ui.theme.NeonBlueSecondary

// ── Available levels ─────────────────────────────────────────────────
private val LEVELS = listOf("A1", "A2", "B1", "B2", "C1")

// ── Available interest chips ─────────────────────────────────────────
private val INTERESTS = listOf(
    "cooking" to "🍳 آشپزی",
    "travel" to "✈️ سفر",
    "technology" to "💻 تکنولوژی",
    "sports" to "⚽ ورزش",
    "music" to "🎵 موسیقی",
    "cinema" to "🎬 سینما",
    "business" to "💼 کسب‌وکار",
    "science" to "🔬 علم"
)

@Composable
fun OnboardingScreen(
    onComplete: (name: String, age: Int, level: String, interests: List<String>) -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var age by remember { mutableIntStateOf(18) }
    var level by remember { mutableStateOf("A1") }
    var interests by remember { mutableStateOf(setOf<String>()) }

    // Step -> slide direction (forward = slide left-in, back = slide right-in)
    var isGoingForward by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // FIX: AnimatedContent so step transitions are animated
        AnimatedContent(
            targetState = step,
            transitionSpec = {
                if (isGoingForward) {
                    (slideInHorizontally { -it } + fadeIn(tween(300))) togetherWith
                            (slideOutHorizontally { it } + fadeOut(tween(200)))
                } else {
                    (slideInHorizontally { it } + fadeIn(tween(300))) togetherWith
                            (slideOutHorizontally { -it } + fadeOut(tween(200)))
                }
            },
            label = "OnboardingStep"
        ) { currentStep ->
            when (currentStep) {
                // ── Step 0: Welcome ───────────────────────────────────
                0 -> {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LumoView(
                                state = LumoState.HAPPY,
                                speechText = "سلام! من لومو هستم ✦"
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "به LingoWorld خوش اومدی!",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "یادگیری انگلیسی بر اساس علایق شما، کاملاً آفلاین و هوشمند",
                                fontSize = 14.sp,
                                color = Color.LightGray,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                            BubbleButton(
                                text = "شروع ماجراجویی",
                                onClick = { isGoingForward = true; step = 1 },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // ── Step 1: Name ──────────────────────────────────────
                1 -> {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LumoView(state = LumoState.THINKING, speechText = "اسمت چیه؟")
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "نام شما",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = name,
                                onValueChange = { if (it.length <= 20) name = it },
                                placeholder = { Text("نام خود را بنویسید...") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = NeonBluePrimary,
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.3f)
                                ),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                BubbleButton(
                                    text = "بازگشت",
                                    onClick = { isGoingForward = false; step = 0 },
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                BubbleButton(
                                    text = "بعدی",
                                    enabled = name.trim().isNotEmpty(),
                                    onClick = { isGoingForward = true; step = 2 },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // ── Step 2: Age ───────────────────────────────────────
                2 -> {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LumoView(state = LumoState.IDLE, speechText = "چند سالته؟")
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "سن شما: $age",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonBluePrimary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.Center) {
                                BubbleButton(text = "−", onClick = { if (age > 5) age-- })
                                Spacer(modifier = Modifier.width(16.dp))
                                BubbleButton(text = "+", onClick = { if (age < 99) age++ })
                            }
                            Spacer(modifier = Modifier.height(20.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                BubbleButton(
                                    text = "بازگشت",
                                    onClick = { isGoingForward = false; step = 1 },
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                BubbleButton(
                                    text = "بعدی",
                                    onClick = { isGoingForward = true; step = 3 },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // ── Step 3: Level (FIX: was completely missing!) ──────
                3 -> {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LumoView(state = LumoState.THINKING, speechText = "سطح انگلیسیت چقدره؟")
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "سطح زبان",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                LEVELS.forEach { lvl ->
                                    val isSelected = level == lvl
                                    Surface(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) NeonBluePrimary
                                                        else Color.White.copy(alpha = 0.25f),
                                                shape = RoundedCornerShape(12.dp)
                                            )
                                            .clickable { level = lvl },
                                        color = if (isSelected)
                                            NeonBluePrimary.copy(alpha = 0.18f)
                                        else Color.Transparent,
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = lvl,
                                            color = if (isSelected) NeonBluePrimary else Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 10.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(20.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                BubbleButton(
                                    text = "بازگشت",
                                    onClick = { isGoingForward = false; step = 2 },
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                BubbleButton(
                                    text = "بعدی",
                                    onClick = { isGoingForward = true; step = 4 },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // ── Step 4: Interests (FIX: was completely missing!) ──
                4 -> {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LumoView(state = LumoState.ENCOURAGE, speechText = "چه موضوعاتی دوست داری؟")
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "علایق شما",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "حداقل یکی انتخاب کن",
                                fontSize = 12.sp,
                                color = Color.LightGray
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Chip grid: 2 columns
                            val rows = INTERESTS.chunked(2)
                            rows.forEach { row ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    row.forEach { (key, label) ->
                                        val isSelected = interests.contains(key)
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(16.dp))
                                                .border(
                                                    width = if (isSelected) 2.dp else 1.dp,
                                                    color = if (isSelected) NeonBlueSecondary
                                                            else Color.White.copy(alpha = 0.2f),
                                                    shape = RoundedCornerShape(16.dp)
                                                )
                                                .clickable {
                                                    interests = if (isSelected)
                                                        interests - key else interests + key
                                                },
                                            color = if (isSelected)
                                                NeonBlueSecondary.copy(alpha = 0.2f)
                                            else Color.Transparent,
                                            shape = RoundedCornerShape(16.dp)
                                        ) {
                                            Text(
                                                text = label,
                                                color = if (isSelected) NeonBlueSecondary else Color.White,
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                textAlign = TextAlign.Center,
                                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp)
                                            )
                                        }
                                    }
                                    // Pad row if odd number
                                    if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                BubbleButton(
                                    text = "بازگشت",
                                    onClick = { isGoingForward = false; step = 3 },
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                BubbleButton(
                                    text = "بعدی",
                                    enabled = interests.isNotEmpty(),
                                    onClick = { isGoingForward = true; step = 5 },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // ── Step 5: Confirmation ──────────────────────────────
                else -> {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            LumoView(state = LumoState.CELEBRATE, speechText = "آماده‌ای شروع کنیم؟ 🎉")
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "سلام $name!",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "سطح: $level  •  سن: $age",
                                fontSize = 14.sp,
                                color = Color.LightGray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "علایق: ${interests.joinToString(", ")}",
                                fontSize = 12.sp,
                                color = NeonBluePrimary.copy(alpha = 0.8f),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            BubbleButton(
                                text = "ورود به دنیای زبان ✦",
                                onClick = { onComplete(name, age, level, interests.toList()) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}
