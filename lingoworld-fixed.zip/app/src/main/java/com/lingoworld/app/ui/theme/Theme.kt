package com.lingoworld.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val DarkColorScheme = darkColorScheme(
    primary = NeonBluePrimary,
    secondary = NeonBlueSecondary,
    tertiary = NeonBlueTertiary,
    background = NeonBlueBg,
    surface = GlassSurface,
    onPrimary = NeonBlueBg,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun LingoWorldTheme(
    content: @Composable () -> Unit
) {
    // Default app direction is Right-to-Left (Persian)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = DarkColorScheme,
            content = content
        )
    }
}
