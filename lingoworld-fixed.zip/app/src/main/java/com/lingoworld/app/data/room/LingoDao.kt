package com.lingoworld.app.data.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LingoDao {
    // Word Progress
    @Query("SELECT * FROM word_progress")
    fun getAllWordProgress(): Flow<List<WordProgressEntity>>

    @Query("SELECT * FROM word_progress WHERE wordId = :wordId LIMIT 1")
    suspend fun getWordProgress(wordId: String): WordProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveWordProgress(progress: WordProgressEntity)

    // Seen Sentences
    @Query("SELECT COUNT(*) FROM seen_sentences WHERE fingerprint = :fingerprint")
    suspend fun isSentenceSeen(fingerprint: String): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSeenSentence(sentence: SeenSentenceEntity)

    @Query("SELECT COUNT(*) FROM seen_sentences")
    suspend fun getSeenCount(): Int

    // FIX: Only trim when above threshold — pass the keep-count so oldest rows are deleted
    // Caller should only invoke this when getSeenCount() > threshold (e.g. 5000)
    @Query("""
        DELETE FROM seen_sentences
        WHERE fingerprint IN (
            SELECT fingerprint FROM seen_sentences
            ORDER BY createdAt ASC
            LIMIT :deleteCount
        )
    """)
    suspend fun trimOldSeenSentences(deleteCount: Int)

    // Daily Stats
    @Query("SELECT * FROM daily_stats ORDER BY date DESC")
    fun getAllDailyStats(): Flow<List<DailyStatEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveDailyStat(stat: DailyStatEntity)

    // Badges
    @Query("SELECT * FROM badges")
    fun getAllBadges(): Flow<List<BadgeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveBadge(badge: BadgeEntity)

    @Query("DELETE FROM word_progress")
    suspend fun clearAllProgress()
}
