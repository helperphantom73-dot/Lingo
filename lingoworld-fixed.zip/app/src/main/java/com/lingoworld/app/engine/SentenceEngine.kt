package com.lingoworld.app.engine

import com.lingoworld.app.data.model.Template
import com.lingoworld.app.data.model.Word

data class GeneratedSentence(
    val id: String,
    val en: String,
    val fa: String,
    val audioText: String,
    val targetWordIds: List<String>,
    val grammarTopic: String,
    val fingerprint: String
)

class SentenceEngine(
    private val allWords: List<Word>,
    private val allTemplates: List<Template>,
    private val isSentenceSeen: suspend (String) -> Boolean
) {
    suspend fun generateSentence(
        level: String,
        topic: String,
        targetWordIds: List<String> = emptyList()
    ): GeneratedSentence? {
        val candidateTemplates = allTemplates.filter { it.level == level }
        val candidateWords = allWords.filter { it.topics.contains(topic) }

        for (attempt in 0 until 30) {
            val tpl = candidateTemplates.randomOrNull() ?: continue
            val sentence = tryFill(tpl, candidateWords) ?: continue

            if (!isSentenceSeen(sentence.fingerprint)) {
                return sentence
            }
        }
        return null
    }

    private fun tryFill(tpl: Template, words: List<Word>): GeneratedSentence? {
        val verbs = words.filter { it.pos == "verb" }
        val nouns = words.filter { it.pos == "noun" }
        if (verbs.isEmpty() || nouns.isEmpty()) return null

        val verb = verbs.random()
        val compatibleNouns = if (verb.acceptsObjectTags.isNotEmpty()) {
            nouns.filter { n -> n.tags.any { it in verb.acceptsObjectTags } }
        } else nouns

        if (compatibleNouns.isEmpty()) return null
        val obj = compatibleNouns.random()

        var en = tpl.pattern
            .replace("{V}", verb.en)
            .replace("{V:3sg}", GrammarUtils.conjugate3sg(verb.en))
            .replace("{O}", obj.en)
            .replace("{ART}", GrammarUtils.getIndefiniteArticle(obj.en))

        var fa = tpl.faPattern
            .replace("{V}", verb.fa)
            .replace("{O}", obj.fa)
            .replace("{ART}", "یک")

        val fp = "${tpl.id}_${verb.id}_${obj.id}"
        return GeneratedSentence(
            id = "sent_${System.currentTimeMillis()}",
            en = en,
            fa = fa,
            audioText = en,
            targetWordIds = listOf(verb.id, obj.id),
            grammarTopic = tpl.grammarTopic,
            fingerprint = fp
        )
    }
}
