package com.lingoworld.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lingoworld.app.ui.theme.NeonBluePrimary
import com.lingoworld.app.ui.theme.NeonBlueSecondary
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

enum class LumoState {
    IDLE, HAPPY, THINKING, ENCOURAGE, CELEBRATE, SLEEPY
}

// Particle for CELEBRATE state
private data class Particle(
    val angle: Float,   // degrees
    val speed: Float,
    val color: Color,
    val size: Float
)

@Composable
fun LumoView(
    modifier: Modifier = Modifier,
    state: LumoState = LumoState.IDLE,
    stage: Int = 1,
    size: Dp = 140.dp,
    speechText: String? = null
) {
    // ── Blink (every 3–6 s, 120 ms closed) ──────────────────────────
    var isBlinking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(Random.nextLong(3000, 6000))
            isBlinking = true
            delay(120)
            isBlinking = false
        }
    }

    // ── Entrance bounce (scale 0→1 on first composition) ────────────
    var launched by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { launched = true }
    val entranceScale by animateFloatAsState(
        targetValue = if (launched) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 300f),
        label = "LumoEntrance"
    )

    // ── Breathing (IDLE / THINKING use slow breath, HAPPY bounces) ──
    val transition = rememberInfiniteTransition(label = "LumoAnim")
    val breathScale by transition.animateFloat(
        initialValue = 1.0f,
        targetValue = when (state) {
            LumoState.HAPPY, LumoState.CELEBRATE -> 1.09f
            LumoState.SLEEPY -> 1.02f
            else -> 1.06f
        },
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    LumoState.HAPPY, LumoState.CELEBRATE -> 700
                    LumoState.SLEEPY -> 2800
                    else -> 1200
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "BreathScale"
    )

    // ── Thinking eye wobble ─────────────────────────────────────────
    val thinkWobble by transition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ThinkWobble"
    )

    // ── Celebrate particle spin ─────────────────────────────────────
    val celebrateSpin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "CelebrateSpin"
    )

    // Static particles for celebrate (created once)
    val particles = remember {
        List(8) {
            Particle(
                angle = it * 45f,
                speed = 1f,
                color = listOf(
                    Color(0xFF00E5FF), Color(0xFFB388FF),
                    Color(0xFF4D7CFF), Color(0xFFFFD700)
                ).random(),
                size = Random.nextFloat() * 5f + 4f
            )
        }
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        // ── Speech Bubble ────────────────────────────────────────────
        if (!speechText.isNullOrEmpty()) {
            Box(
                modifier = Modifier
                    .offset(y = (-72).dp)
                    .padding(horizontal = 4.dp)
            ) {
                GlassCard {
                    Text(
                        text = speechText,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // FIX: Use graphicsLayer scale instead of Modifier.size(size * breathScale)
        // to avoid layout jumps and recomposition of children on every frame
        Canvas(
            modifier = Modifier
                .size(size)
                .graphicsLayer {
                    scaleX = breathScale * entranceScale
                    scaleY = breathScale * entranceScale
                }
        ) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.minDimension * 0.32f

            // ── 1. Outer Neon Glow ───────────────────────────────────
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NeonBluePrimary.copy(alpha = 0.35f), Color.Transparent),
                    center = center,
                    radius = radius * 1.55f
                ),
                radius = radius * 1.55f,
                center = center
            )

            // ── 2. Celebrate Particles ───────────────────────────────
            if (state == LumoState.CELEBRATE) {
                particles.forEach { p ->
                    val rad = Math.toRadians((p.angle + celebrateSpin).toDouble())
                    val px = center.x + cos(rad).toFloat() * radius * 1.65f
                    val py = center.y + sin(rad).toFloat() * radius * 1.65f
                    drawCircle(color = p.color, radius = p.size, center = Offset(px, py))
                }
            }

            // ── 3. Stage 2+ Antenna ──────────────────────────────────
            if (stage >= 2) {
                drawLine(
                    color = NeonBluePrimary,
                    start = Offset(center.x, center.y - radius * 0.9f),
                    end = Offset(center.x + 4f, center.y - radius * 1.35f),
                    strokeWidth = 5f,
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = Color.White,
                    radius = 8f,
                    center = Offset(center.x + 4f, center.y - radius * 1.38f)
                )
            }

            // ── 4. Body ──────────────────────────────────────────────
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NeonBluePrimary.copy(alpha = 0.55f),
                        NeonBlueSecondary.copy(alpha = 0.35f),
                        Color(0xFFB388FF).copy(alpha = 0.15f)
                    ),
                    center = Offset(center.x - radius * 0.25f, center.y - radius * 0.35f),
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            // ── 5. Rim Light ─────────────────────────────────────────
            val rimAlpha = if (state == LumoState.CELEBRATE) 0.9f else 0.6f
            drawCircle(
                color = Color.White.copy(alpha = rimAlpha),
                radius = radius,
                center = center,
                style = Stroke(width = 4f)
            )

            // ── 6. Specular Highlight ────────────────────────────────
            drawOval(
                color = Color.White.copy(alpha = 0.75f),
                topLeft = Offset(center.x - radius * 0.55f, center.y - radius * 0.65f),
                size = Size(radius * 0.45f, radius * 0.25f)
            )

            // ── 7. Eyes ──────────────────────────────────────────────
            val eyeSpacing = radius * 0.42f
            val eyeY = center.y - radius * 0.05f +
                    if (state == LumoState.THINKING) thinkWobble * 0.3f else 0f
            val eyeWidth = radius * 0.28f
            val eyeHeight = when {
                isBlinking || state == LumoState.SLEEPY -> 3f
                state == LumoState.HAPPY || state == LumoState.CELEBRATE -> radius * 0.26f // squint happy
                else -> radius * 0.38f
            }

            listOf(center.x - eyeSpacing, center.x + eyeSpacing).forEach { ex ->
                // Thinking: eyes shift slightly up
                val eyeOffsetY = if (state == LumoState.THINKING) thinkWobble * 0.5f else 0f
                drawOval(
                    color = Color(0xFF060A17),
                    topLeft = Offset(ex - eyeWidth / 2f, eyeY - eyeHeight / 2f + eyeOffsetY),
                    size = Size(eyeWidth, eyeHeight)
                )
                if (!isBlinking && state != LumoState.SLEEPY) {
                    drawCircle(
                        color = Color.White,
                        radius = eyeWidth * 0.22f,
                        center = Offset(ex - 2f, eyeY - 3f + eyeOffsetY)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = 0.8f),
                        radius = eyeWidth * 0.1f,
                        center = Offset(ex + 3f, eyeY + 3f + eyeOffsetY)
                    )
                }
            }

            // ── 8. Mouth — shape changes per state ───────────────────
            val mouthY = eyeY + radius * 0.32f
            val mouthColor = Color.White

            when (state) {
                LumoState.SLEEPY -> {
                    // Flat / slightly frowning line
                    drawLine(
                        color = mouthColor.copy(alpha = 0.6f),
                        start = Offset(center.x - radius * 0.18f, mouthY),
                        end = Offset(center.x + radius * 0.18f, mouthY + 2f),
                        strokeWidth = 3.5f,
                        cap = StrokeCap.Round
                    )
                }
                LumoState.THINKING -> {
                    // Small mouth — pursed
                    drawArc(
                        color = mouthColor,
                        startAngle = 160f,
                        sweepAngle = 40f,
                        useCenter = false,
                        topLeft = Offset(center.x - radius * 0.14f, mouthY - radius * 0.08f),
                        size = Size(radius * 0.28f, radius * 0.18f),
                        style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                    )
                }
                LumoState.HAPPY, LumoState.CELEBRATE, LumoState.ENCOURAGE -> {
                    // Big wide smile
                    drawArc(
                        color = mouthColor,
                        startAngle = 10f,
                        sweepAngle = 160f,
                        useCenter = false,
                        topLeft = Offset(center.x - radius * 0.26f, mouthY - radius * 0.12f),
                        size = Size(radius * 0.52f, radius * 0.32f),
                        style = Stroke(width = 4.5f, cap = StrokeCap.Round)
                    )
                }
                else -> {
                    // Default neutral smile
                    drawArc(
                        color = mouthColor,
                        startAngle = 20f,
                        sweepAngle = 140f,
                        useCenter = false,
                        topLeft = Offset(center.x - radius * 0.2f, mouthY - radius * 0.1f),
                        size = Size(radius * 0.4f, radius * 0.25f),
                        style = Stroke(width = 4f, cap = StrokeCap.Round)
                    )
                }
            }
        }
    }
}
