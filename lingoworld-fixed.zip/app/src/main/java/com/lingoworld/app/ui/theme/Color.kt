package com.lingoworld.app.ui.theme

import androidx.compose.ui.graphics.Color

// Neon Blue Theme
val NeonBlueBg = Color(0xFF070A1A)
val NeonBluePrimary = Color(0xFF00E5FF)
val NeonBlueSecondary = Color(0xFF4D7CFF)
val NeonBlueTertiary = Color(0xFFB388FF)

// Neon Purple Theme
val NeonPurpleBg = Color(0xFF0D0618)
val NeonPurplePrimary = Color(0xFFC77DFF)
val NeonPurpleSecondary = Color(0xFFFF4DCC)
val NeonPurpleTertiary = Color(0xFF7C4DFF)

// Neon Green Theme
val NeonGreenBg = Color(0xFF04120D)
val NeonGreenPrimary = Color(0xFF00FFA3)
val NeonGreenSecondary = Color(0xFF00D1FF)
val NeonGreenTertiary = Color(0xFFB6FF00)

// Shared Surface Colors
val GlassSurface = Color(0x14FFFFFF)
val GlassBorder = Color(0x3300E5FF)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
