package com.lingoworld.app.data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        WordProgressEntity::class,
        SeenSentenceEntity::class,
        DailyStatEntity::class,
        BadgeEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LingoDatabase : RoomDatabase() {
    abstract fun lingoDao(): LingoDao

    companion object {
        @Volatile
        private var INSTANCE: LingoDatabase? = null

        fun getDatabase(context: Context): LingoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LingoDatabase::class.java,
                    "lingoworld_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
