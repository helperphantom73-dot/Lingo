package com.lingoworld.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.lingoworld.app.ui.theme.NeonBlueBg
import com.lingoworld.app.ui.theme.NeonBluePrimary
import com.lingoworld.app.ui.theme.NeonBlueSecondary
import com.lingoworld.app.ui.theme.NeonBlueTertiary

@Composable
fun NeonBackground(
    modifier: Modifier = Modifier,
    isLowPowerMode: Boolean = false
) {
    val transition = rememberInfiniteTransition(label = "NeonOrbs")
    val shift1 by transition.animateFloat(
        initialValue = -40f,
        targetValue = 40f,
        animationSpec = infiniteRepeatable(
            animation = tween(18000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Shift1"
    )
    val shift2 by transition.animateFloat(
        initialValue = 30f,
        targetValue = -30f,
        animationSpec = infiniteRepeatable(
            animation = tween(22000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Shift2"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        // Base Dark Background
        drawRect(color = NeonBlueBg)

        // Orb 1: Cyan
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(NeonBluePrimary.copy(alpha = 0.45f), Color.Transparent),
                center = Offset(size.width * 0.2f + shift1, size.height * 0.2f),
                radius = size.maxDimension * 0.35f
            ),
            radius = size.maxDimension * 0.35f,
            center = Offset(size.width * 0.2f + shift1, size.height * 0.2f)
        )

        // Orb 2: Cobalt
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(NeonBlueSecondary.copy(alpha = 0.40f), Color.Transparent),
                center = Offset(size.width * 0.8f, size.height * 0.3f + shift2),
                radius = size.maxDimension * 0.40f
            ),
            radius = size.maxDimension * 0.40f,
            center = Offset(size.width * 0.8f, size.height * 0.3f + shift2)
        )

        if (!isLowPowerMode) {
            // Orb 3: Lavender
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NeonBlueTertiary.copy(alpha = 0.38f), Color.Transparent),
                    center = Offset(size.width * 0.5f + shift2, size.height * 0.75f),
                    radius = size.maxDimension * 0.36f
                ),
                radius = size.maxDimension * 0.36f,
                center = Offset(size.width * 0.5f + shift2, size.height * 0.75f)
            )
        }
    }
}
