package com.lingoworld.app.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "user_preferences")

class UserPreferences(private val context: Context) {
    companion object {
        val KEY_NAME = stringPreferencesKey("user_name")
        val KEY_AGE = intPreferencesKey("user_age")
        val KEY_LEVEL = stringPreferencesKey("user_reported_level")
        val KEY_INTERESTS = stringSetPreferencesKey("user_interests")
        val KEY_XP = intPreferencesKey("user_xp")
        val KEY_STREAK = intPreferencesKey("user_streak")
        val KEY_THEME = stringPreferencesKey("app_theme")
        val KEY_GRAPHIC_TIER = stringPreferencesKey("app_graphic_tier")
        val KEY_TTS_SPEED = floatPreferencesKey("tts_speed")
        val KEY_REMINDER_HOUR = intPreferencesKey("reminder_hour")
        val KEY_ONBOARDING_DONE = booleanPreferencesKey("onboarding_completed")
    }

    val userName: Flow<String> = context.dataStore.data.map { it[KEY_NAME] ?: "" }
    val userAge: Flow<Int> = context.dataStore.data.map { it[KEY_AGE] ?: 18 }
    val userLevel: Flow<String> = context.dataStore.data.map { it[KEY_LEVEL] ?: "A1" }
    val userInterests: Flow<Set<String>> = context.dataStore.data.map { it[KEY_INTERESTS] ?: setOf("cooking") }
    val userXp: Flow<Int> = context.dataStore.data.map { it[KEY_XP] ?: 0 }
    val userStreak: Flow<Int> = context.dataStore.data.map { it[KEY_STREAK] ?: 1 }
    val appTheme: Flow<String> = context.dataStore.data.map { it[KEY_THEME] ?: "neon-blue" }
    val graphicTier: Flow<String> = context.dataStore.data.map { it[KEY_GRAPHIC_TIER] ?: "high" }
    val ttsSpeed: Flow<Float> = context.dataStore.data.map { it[KEY_TTS_SPEED] ?: 0.9f }
    val reminderHour: Flow<Int> = context.dataStore.data.map { it[KEY_REMINDER_HOUR] ?: 20 }
    val isOnboardingDone: Flow<Boolean> = context.dataStore.data.map { it[KEY_ONBOARDING_DONE] ?: false }

    suspend fun saveProfile(name: String, age: Int, level: String, interests: Set<String>) {
        context.dataStore.edit { prefs ->
            prefs[KEY_NAME] = name
            prefs[KEY_AGE] = age
            prefs[KEY_LEVEL] = level
            prefs[KEY_INTERESTS] = interests
            prefs[KEY_ONBOARDING_DONE] = true
        }
    }

    suspend fun addXp(amount: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_XP] ?: 0
            prefs[KEY_XP] = current + amount
        }
    }

    suspend fun setTheme(theme: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_THEME] = theme
        }
    }

    suspend fun setGraphicTier(tier: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_GRAPHIC_TIER] = tier
        }
    }
}
