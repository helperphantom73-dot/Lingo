package com.lingoworld.app.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lingoworld.app.ui.theme.NeonBluePrimary
import com.lingoworld.app.ui.theme.NeonBlueSecondary

@Composable
fun BubbleButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val view = LocalView.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // FIX: Spring press scale — correct order (scale wraps box, not inside)
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = spring(dampingRatio = 0.45f, stiffness = 500f),
        label = "BubbleButtonScale"
    )

    // ENHANCEMENT: Shimmer animation along gradient offset
    val shimmerTransition = rememberInfiniteTransition(label = "shimmer")
    val shimmerOffset by shimmerTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmerOffset"
    )

    val gradient = Brush.horizontalGradient(
        colorStops = arrayOf(
            (shimmerOffset - 0.3f).coerceIn(0f, 1f) to NeonBlueSecondary,
            shimmerOffset.coerceIn(0f, 1f) to NeonBluePrimary,
            ((shimmerOffset + 0.3f).coerceIn(0f, 1f)) to NeonBlueSecondary
        )
    )

    // FIX: scale applied outside; defaultMinSize before padding
    Box(
        modifier = modifier
            .scale(scale)
            .alpha(if (enabled) 1.0f else 0.4f)
            .clip(CircleShape)
            .background(gradient, CircleShape)
            .defaultMinSize(minHeight = 48.dp)   // FIX: before padding
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null
            ) {
                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onClick()
            }
            .padding(horizontal = 24.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color(0xFF060A17),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
